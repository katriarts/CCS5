package presentation;
import java.util.*;
public class RoundRobin3 {
    Scanner sc = new Scanner(System.in);
    int[] bur, rem, wai, ta;
    int size, q, b=0, t=0, flag=0;    
    RoundRobin3(int size){
        this.size = size;
        bur = new int[size];
        wai = new int[size];
        ta = new int[size];
        rem = new int[size];
    }
    void get(){
        for(int i=0; i<size; i++){
            System.out.print("Enter Burst Time of P "+ (i+1)+ ":" );
            bur[i]= rem[i]= sc.nextInt();
        }   
        int minBT=bur[0], maxBT=0;
        for(int i=0; i<size; i++){
            if(bur[i]  < minBT)
                minBT = bur[i];
        }
        for(int i=0; i<size; i++){
            if(bur[i] > maxBT)
                maxBT = bur[i];;
        }
            //System.out.println("Max: "+maxBT);
            //System.out.println("Min: "+minBT);
            //float temp=(minBT+maxBT);
            /**new computed TQ*/
            //q=(int)temp/size;
            System.out.println("Enter Quantum Time: ");
            float temp= sc.nextInt();
            q= (int)temp;
            
        System.out.print("Quantum Time: "+q);
        
    }
    void round(){
        do{
            flag=0;
            for(int i=0; i<size; i++){
                if(rem[i]>=q){
                    System.out.println("P"+ (i+1)+"\t");
                    for(int j=0; j<size; j++){
                        if(j==i)
                            rem[i]=rem[i]-q;
                        else if(rem[j]>0)
                            wai[j]+=q;
                    }
                }
                else if(rem[i]>0){
                    System.out.println("P"+(i+1)+"\t");
                    for(int j=0; j<size; j++){
                        if(j==i)
                            rem[i]=0;
                        else if(rem[j]>0)
                            wai[j]+=rem[i];
                    }
                }
            }
            for(int i=0; i<size; i++)
                if(rem[i]>0)
                    flag=1;
        }while(flag==1);
        for(int i=0; i<size; i++)
            ta[i]=wai[i]+bur[i];
    }
    void display(){
        System.out.println("\nProcess\tBurst\tWaiting\t Turnaround");
        for(int i=0; i<size; i++){
            System.out.println("P"+(i+1)+"\t   "+bur[i]+"\t   "+wai[i]+"\t   "+ta[i]);
            b+=wai[i];
            t+=ta[i];
        }
        System.out.println("Average Waiting Time: "+(b/size));
        System.out.println("Average Turnaround Time: "+(t/size));
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the no. of process: ");
        int n = s.nextInt();
        RoundRobin3 obj = new RoundRobin3(n);
        obj.get();
        obj.round();
        obj.display();
    }
    
}
