package presentation;
import java.util.*;
public class RRSJF3 {
    Scanner sc = new Scanner(System.in);
    /**BT=burst time; rem=remaining time(BT storage); WT=waiting time; TT=turnaround time */
    int[] BT, rem, WT, TT;
    /**size=n; TQ=time quantum, b=WT storage; t=TT storage; flag=check for TQ*/
    int size, TQ, b=0, t=0, flag=0, i=0;
    /**n(from the main method) == size*/
        int TQnew;//= TQ;

    RRSJF3(int size){
        this.size = size;
        BT = new int[size];
        WT = new int[size];
        TT = new int[size];
        rem = new int[size];
    }
    /**input the burst time of every process*/
/**3. n elements == size; i= increment every loop*/
    void get(){
        for( i=0; i<size; i++){
            System.out.print("Enter Burst Time of P"+ (i+1)+ ":" );
            /**burst time is stored for remaining burst time calculation later*/
            //BT[i]= rem[i]= sc.nextInt();   
            rem[i] = sc.nextInt();
            if((BT[i]!=0)|| (BT[i] ==0) ){
                BT[i] = rem[i];}
        }
    } 
/**all entered BT are stored on rem*/
/**5. look for the minimum and maximum burst times*/
    void minmax(){  
        int minBT=BT[0], maxBT=0;
        for( i=0; i<size; i++){
            if(BT[i]  < minBT)
                minBT = BT[i];
        }
        for( i=0; i<size; i++){
            if(BT[i] > maxBT)
                maxBT = BT[i];;
        }
            System.out.println("Max: "+maxBT);
            System.out.println("Min: "+minBT);
            float temp=(minBT+maxBT)/size;
            /**new computed TQ*/
            TQ=(int)temp+((int)temp/2)*i;
            TQnew= TQ;
            System.out.println("Time Quantum: "+TQnew);
            
    }
/**4. processes stored will be arranged in ascending order*/
    void arrange(){
        System.out.println("ASCENDING ORDER:");    
        for( i=0; i<size; i++){
            Arrays.sort(BT);
            System.out.print("P"+(i+1)+":"+BT[i]+", ");
        }System.out.println("");
    }

/**6. method for process according to its priority (shortest first)*/
    /**check if remaining time (BT) is greater than or not in comparison to the computed TQ, 
     * then execute the following condition*/
    void round(){
        System.out.println("-----GANTT CHART-----");
        Arrays.sort(rem);
        do{       
            flag=0;
            for( i=0; i<size; i++){ 
                if(rem[i]>=TQnew){
                    System.out.print("P"+ (i+1)+" | ");
                    for(int j=0; j<size; j++){
                        if(j==i)
                            rem[i]=rem[i]-TQnew;
                        else if(rem[j]>0)
                            WT[j]+=TQnew;
                    }
                }
                else if(rem[i]>0){
                    System.out.print("P"+(i+1)+" | ");
                    for(int j=0; j<size; j++){
                        if(j==i)
                            rem[i]=0;
                        else if(rem[j]>0)
                            WT[j]+=rem[i];
                    }
                }
            }
            for( i=0; i<size; i++)
                if(rem[i]>0)
                    flag=1;
        }while(flag==1);
        for( i=0; i<size; i++)
            TT[i]=WT[i]+BT[i];
       
    }
    void display(){
        
        System.out.println("");
        System.out.println("----------------------------------------");
        System.out.println("Process  Burst  Priority  Waiting  Turnaround");
        for( i=0; i<size; i++){
            System.out.println("P"+(i+1)+"\t   "+BT[i]+"\t   "+(i+1)+"\t     "+WT[i]+"\t       "+TT[i]);
            b+=(float)WT[i];
            t+=(float)TT[i];
        }
/**10. calculate average of WT and average of TT and CS*/
        System.out.println("Average Waiting Time: "+(b/size));
        System.out.println("Average Turnaround Time: "+(t/size));
        System.out.println("cs: "+(i+1));
    }
    public static void main(String[] args) {
            Scanner s = new Scanner(System.in);
/**1. Start the process by running the program*/
/**2. declare the number of process*/
        System.out.print("Enter the no. of process: ");
        int n = s.nextInt();
        /**take n elements*/
        RRSJF3 obj = new RRSJF3(n);
        obj.get();
        obj.minmax();
        obj.arrange();
        obj.round();
        obj.display();


    
    }
    
}

