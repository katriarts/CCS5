package presentation;
import ShortestJobFirst.*;
import java.util.*;
public class ShortestJobFirst {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of process: ");
        int n = sc.nextInt();
        int pid[] = new int[n];
        int at[] = new int[n];  //arrival time
        ////////////////////////////////////////////
        int bt[] = new int[n];  //burst time
        int ta[] = new int[n];  //turnaround time
        int wt[] = new int[n];  //waiting time

        int ct[] = new int[n];  //complete time
        int f[] = new int[n];   //flag, checks process is complete or not
        
        int st=0, tot=0;    //st: system time; tot: # of processes
        float avgwt=0, avgta=0;
        
        for(int i=0; i<n; i++){
           // System.out.println("Enter process "+ (i+1) + "Arrival Time: ");
            at[i] = 0;//sc.nextInt();
            System.out.println("Enter process "+ (i+1) + "Burst Time: ");
            bt[i] = sc.nextInt();
            pid[i] = i+1;
            f[i] = 0;
        }
        boolean a = true;
        while(true){
            int c=n, min=999;
            if(tot == n)    //total number of process==completed process loop is terminated
                break;
            
            for(int i=0; i<n; i++){
                /*if process arrival time <= system time & flag =0 & burst<min
                that process will be executed first
                */
                if((at[i]<=st) && (f[i]==0) && (bt[i]<min)){
                    min=bt[i];
                    c=i;
                }
            }
            //if c==n, c cannot update because no process arrival time < system time so we can increase system time
            if(c==n)
                st++;
            else{
                ct[c]=st+bt[c];
                st+=bt[c];
                ta[c]=ct[c]-at[c];
                wt[c]=ta[c]-bt[c];
                f[c]=1;
                tot++;
            }
        }
        
        System.out.println("\npid arrival burst complete turn waiting");
        for(int i=0; i<n; i++){
            avgwt+= wt[i];
            avgta+= ta[i];
            System.out.println(pid[i]+"\t"+at[i]+"\t"+bt[i]+"\t"+ct[i]+"\t"+ta[i]+"\t"+wt[i]);
        }
        
        System.out.println("\naverage tat is "+ (float)(avgta/n));
        System.out.println("\naverage wt is "+ (float) (avgwt/n));
    }
    
}
