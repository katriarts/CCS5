package RoundRobin;
import java.util.*;
public class RoundRobin {
//------------------------------------------------------------------------------
    //method to find waiting time
    static void findWaitingTime(int processs[], int n, int bt[], int wt[], int quantum){
        //make a copy of burst time bt[] to store remaining burst time
        int rem_bt[] = new int[n];
        for(int i=0; i<n; i++)
            rem_bt[i] = bt[i];
        
        int t = 0; //current time
        
        //process continues in round robin until all are not yet done
        while(true){
            boolean done= true;
            //process one by one repeatedly
            for(int i=0; i<n;i++){
                //if bt>0, then process
                if(rem_bt[i]>0){
                    done=false; //pending process
                    
                    if(rem_bt[i]>quantum){
                        //increase value of t
                        t+=quantum;
                        rem_bt[i]-=quantum;
                    }
                    //if bt<=0, process last cycle
                    else{
                        //increase value of t
                        t=t+rem_bt[i];
                        
                        //waiting time: current time - time used by this process
                        wt[i]= t-bt[i];
                        
                        //as process gets fully executed, make remaining bt=0
                        rem_bt[i]=0;   
                    }
                }
            }
            //if all processes are done
            if(done==true)
                break;
        }
    }
//------------------------------------------------------------------------------
    //method to find turnaround time
    static void findTurnAroundTime(int process[], int n, int bt[], int wt[], int tat[]){
        //calculate turnaround time by adding bt[i] + wt[i]
        for(int i=0; i<n; i++)
            tat[i]= bt[i] + wt[i];
    }
//------------------------------------------------------------------------------
    //calculate AVERAGE TIME
    static void findavgTime(int processes[], int n, int bt[], int quantum){
        int wt[] = new int[n], tat[]=new int[n];
        int total_wt=0, total_tat=0;
        
        //function to find WAITING TIME of all process
        findWaitingTime(processes, n, bt, wt, quantum);
        //function to find TURNAROUND TIME of all process
        findTurnAroundTime(processes, n, bt, wt, tat);
        
        //display processes!!!
        System.out.println("Processes "+ " Burst Time "+ " Waiting Time "+ " Turnaround Time");
        
        //calculate TOTAL WAITING TIME & TURNAROUND TIME
        for(int i=0; i<n; i++){
            total_wt= total_wt+wt[i];
            total_tat=total_tat+tat[i];
            
            System.out.println(" " + (i+1) + "\t\t" + bt[i] + "\t" + wt[i] + "\t\t" + tat[i]);
        }
        
        System.out.println("Average Waiting time: " + (float)total_wt / (float)n);
        System.out.println("Average Turnaround time: "+ (float)total_tat/(float)n);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        //process id's
        
        int processes[]= {1,2,3,4,5};
        int n=processes.length;
        
//burst time of all processes

        int burst_time[]={10,8,7,6,9};
        //time quantum
        int quantum=3;
        findavgTime(processes, n, burst_time, quantum);
    }
    
}
