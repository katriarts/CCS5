package finaltry;
import java.util.*;
public class rrstf {
    Scanner sc = new Scanner(System.in);
    int[] BT, rem, WT, TT, TQnew;
    /**size=n; TQ=time quantum, b=WT storage; t=TT storage; flag=check for TQ*/
    int size, TQ, b=0, t=0, flag=0, i=0;
    /**n(from the main method) == size*/
//    int TQnew;//= TQ;
    int minBT, maxBT;
    rrstf(int size){
        this.size = size;
        BT = new int[size];
        WT = new int[size];
        TT = new int[size];
        rem = new int[size];   
        TQnew = new int[size];
    }
    //input burst time per process
    void get(){
        for( i=0; i<size; i++){
            System.out.print("Enter Burst Time of P"+ (i+1)+ ":" );
            /**burst time is stored for remaining burst time calculation later*/
            //BT[i]= rem[i]= sc.nextInt();   
            rem[i] = sc.nextInt();
            if((BT[i]!=0)|| (BT[i] ==0) ){
                BT[i] = rem[i];}
        }
    }
    
    //search for minimum and maximum burst time
    void minmax(){  
                 minBT=BT[0]; maxBT=0;

        for( i=0; i<size; i++){
            if(BT[i]  < minBT)
                minBT = BT[i];
        }
        
        for( i=0; i<size; i++){
            if(BT[i] > maxBT)
                maxBT = BT[i];;
        //originally dito ang curly brace
        }
        System.out.println("Max: " + maxBT);
        System.out.println("Min: " + minBT);

    }
    
    //arrange burst times in ascending order
    void arrange(){
        System.out.println("ASCENDING ORDER:");    
        for( i=0; i<size; i++){
            Arrays.sort(BT);
            System.out.print("P"+(i+1)+":"+BT[i]+", ");
        }System.out.println("");
    }
    
    //compute and display gantt chart
    void round(){              
        System.out.println("-----GANTT CHART-----");
        Arrays.sort(rem);
        do{       
            flag=0;
            float temp=(minBT+maxBT)/size;    
            
            for(i=0; i<size; i++){
                //if  rem is greater than or equal to TQnew
            TQ=(int)temp+((int)temp/2);
            TQnew[i] = TQ+i;
                if(rem[i]>=TQnew[i]){
                    System.out.print("P"+ (i+1)+" | ");
                    for(int j=0; j<size; j++){
                            if(j==i)
                            rem[i]=rem[i]-TQnew[i];
                        else if(rem[j]>0)
                            WT[j]+=TQnew[i];
                    }    
                }
                else {
                    System.out.print("P"+(i+1)+" | ");
                    for(int j=0; j<size; j++){
                        if(j==i)
                            rem[i]=0;
                        else if(rem[j]>0)
                            WT[j]+=rem[i];
                    }
                }System.out.println("TQ: "+TQnew[i]);   
                
            }
            for( i=0; i<size; i++)
                if(rem[i]>0)
                    flag=1;
        }while(flag==1);
        for( i=0; i<size; i++)
            TT[i]=WT[i]+BT[i];  
    }
           
    
    //display results
        void display(){
        
        ///////////////
        System.out.println("");
        System.out.println("----------------------------------------");
        System.out.println("Process  Burst  Priority  Waiting  Turnaround  ");
        for( i=0; i<size; i++){
            System.out.println("P"+(i+1)+"\t   "+BT[i]+"\t   "+(i+1)+"\t     "+WT[i]+"\t       "+TT[i] +"   "+TQnew[i]);
            b+=(float)WT[i];
            t+=(float)TT[i];
        }
System.out.println("Average Waiting Time: "+(b/size));
        System.out.println("Average Turnaround Time: "+(t/size));
//        System.out.println("cs: "+(i+1));
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the no. of process: ");
        int n = s.nextInt();
        
                rrstf obj = new rrstf(n);
        obj.get();
        obj.minmax();
        obj.arrange();
        obj.round();
        obj.display();

        
    }
    
}
